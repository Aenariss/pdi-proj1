
python3 ./src/redirectToLocalhost.py &
python3 ./src/dataDownloader.py "$@"